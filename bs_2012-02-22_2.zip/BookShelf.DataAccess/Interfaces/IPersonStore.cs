﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BookShelf.Model;

namespace BookShelf.DataAccess.Interfaces
{
    public interface IPersonStore : IEntityStore<Person>
    {

    }
}
