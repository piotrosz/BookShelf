﻿using System;
using System.ComponentModel;

namespace BookShelf.Model
{
    public class Person : IComparable, IDataErrorInfo, IComparable<Person>
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName { get { return string.Format("{0} {1}", FirstName, LastName); } }

        public int CompareTo(object obj)
        {
            return Id.CompareTo(((Person)obj).Id);
        }

        public int CompareTo(Person other)
        {
            return this.Id.CompareTo(other.Id);
        }

        public string Error
        {
            get { return ""; }
        }

        public string this[string columnName]
        {
            get
            {
                string result = null;
                if (columnName == "FirstName")
                {
                    if (string.IsNullOrWhiteSpace(FirstName))
                        result = "Please enter a firstname";
                }
                else if (columnName == "LastName")
                {
                    if (string.IsNullOrWhiteSpace(LastName))
                        result = "Please enter a lastname";
                }
                return result;
            }
        }

        public override string ToString()
        {
            return FullName;
        }
    }
}
