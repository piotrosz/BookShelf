﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookShelf.Model.SearchParams
{
    public class CategorySearchParams : SearchParamsBase
    {
        public string Name { get; set; }
    }
}
