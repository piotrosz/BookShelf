﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookShelf.Model.SearchParams
{
    public class BookSearchParams : SearchParamsBase
    {
        public string Title { get; set; }

    }
}
