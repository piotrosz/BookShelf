﻿using System;

namespace BookShelf.Model
{
    public class Author : Person
    {
    }
}
